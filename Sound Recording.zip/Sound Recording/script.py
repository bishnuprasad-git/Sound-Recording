from flask import *

import sounddevice as sd
from scipy.io.wavfile import write
import wavio as wv

import os.path
from os import path

app = Flask(__name__)

@app.route('/')
def home():
    freq=44100
    duration=5
    recording=sd.rec(int(duration*freq),samplerate=freq,channels=2)
    sd.wait()
    write(os.path.join(os.getcwd()+'\\static\\record.wav'),freq,recording)
    wv.write(os.path.join(os.getcwd()+'\\static\\record.wav'),recording,freq,sampwidth=2)
    data={'fld':'hello'}
    # return jsonify(data)
    return render_template('home.html')
    # p=2
    # print(f"hello {p}")
    # return "hello"

@app.route('/client')
def client():
    p=os.path.exists('static/record.wav')
    k='Not recordings found'
    if(p==True):
        k='Click here to download the recorded file'
        return render_template('client.html',name=k,o='record.wav')
    return "No file found"


if __name__ == '__main__':
    app.run(debug=True)




